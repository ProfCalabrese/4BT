/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testpokemon;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author K41w3
 */
abstract public class Pokemon {
    private String nome;
    private String tipo1;
    private String tipo2;
    private String razza;
    private int numero;
    private int psMax;
    private int psAttuali;
    private int velocita;
    ArrayList <Mosse> mosse;
    Random rand=new Random();
    Scanner s=new Scanner(System.in);
    int n;
    public  abstract Pokemon breeding(Pokemon genitore, String nomeF);
    public Pokemon(String nome,String tipo1,String tipo2,String razza,int numero,int psMax,int velocita){
        setNome(nome);
        setTipo1(tipo1);
        setTipo2(tipo2);
        setRazza(razza);
        setNumero(numero);
        setPsMax(psMax);
        setVelocita(velocita);
        psAttuali=psMax;
        mosse=new ArrayList();
    }

  /*  public Pokemon breeding(Pokemon genitore,String nomeFiglio,int numeroFiglio){
        if(genitore.getRazza().equals(razza)){
            Pokemon p=new Pokemon(nomeFiglio,tipo1,genitore.getTipo2(),razza,numeroFiglio,(genitore.getPsMax()+psMax)/2,(genitore.getVelocita()+velocita)/2);
            return p;
        }
        return null;
    }*/
    
    public int attacca(){
        for(int i=0;i<mosse.size();i++){
            System.out.println("mossa "+i+": "+mosse.get(i).getNome());
        }
      
        System.out.println("che mossa vuoi usare? ");
        n=s.nextInt();
        return rand.nextInt(100-mosse.get(n).getPrecisione());
    }
    
    public void fuga(int velocita){    // considerando una velocita max di 100
        n=rand.nextInt(99)+1;
        if(n+this.velocita>velocita)
            System.out.println("sei scappato! ");
    }
    public void cura(){
        if(psAttuali+50>=100)
            psAttuali=100;
        else
            psAttuali+=50;
        
    }
   public void imparaMossa(Mosse mossa){
       if(mosse.size()<4)
             mosse.add(mossa);
       else
           mosse.removeFirst();
           mosse.addFirst(mossa);
   }
    public void cheatMossa(Mosse mossa){
        mosse.add(mossa);
    }
    public void dimenticaMossa(){
        for(int i=0;i<mosse.size();i++){
            System.out.println("mossa " +i +": "+mosse.get(i).getNome());
            
        }
        int scelta;
        System.out.println("che mossa vuoi eliminare? ");
        scelta=s.nextInt();
        mosse.remove(scelta);
        
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTipo1(String tipo1) {
        this.tipo1 = tipo1;
    }

    public void setTipo2(String tipo2) {
        this.tipo2 = tipo2;
    }

    public void setRazza(String razza) {
        this.razza = razza;
    }

    public void setNumero(int numero) {
        if(numero>=0)
           this.numero = numero;
    }

    public void setPsMax(int psMax) {
        if(psMax>0)
          this.psMax = psMax;
    }


    public void setVelocita(int velocita) {
        if(velocita>=0)
           this.velocita = velocita;
    }

    
    
    
    public String getNome() {
        return nome;
    }

    public String getTipo1() {
        return tipo1;
    }

    public String getTipo2() {
        return tipo2;
    }

    public String getRazza() {
        return razza;
    }

    public int getNumero() {
        return numero;
    }

    public int getPsMax() {
        return psMax;
    }

    public int getPsAttuali() {
        return psAttuali;
    }

    public int getVelocita() {
        return velocita;
    }
    
    
    
}
