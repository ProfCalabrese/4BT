/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testpokemon;

/**
 *
 * @author K41w3
 */
public class Mosse {
    private String tipo;
    private String nome;
    private String descrizione;
    private int attacco;
    private int precisione;
    
    public Mosse(String tipo,String nome,String descrizione,int attacco,int precisione){
        setTipo(tipo);
        setNome(nome);
        setDescrizione(descrizione);
        setAttacco(attacco);
        setPrecisione(precisione);
    }

    
    
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public int getAttacco() {
        return attacco;
    }

    public void setAttacco(int attacco) {
        if(attacco>=0)
            this.attacco = attacco;
    }

    public int getPrecisione() {
        return precisione;
    }

    public void setPrecisione(int precisione) {
        if(precisione>=0)
             this.precisione = precisione;
    }
            
}
