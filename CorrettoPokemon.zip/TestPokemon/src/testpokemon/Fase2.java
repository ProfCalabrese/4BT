/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testpokemon;

/**
 *
 * @author K41w3
 */
public class Fase2 extends Pokemon{
    private int livelloMin;
    public Fase2(String nome, String tipo1, String tipo2, String razza, int numero, int psMax, int velocita) {
        super(nome, tipo1, tipo2, razza, numero, psMax, velocita);
    }
    
   @Override
    public Pokemon breeding(Pokemon genitore, String nomeF) {
        if(genitore.getRazza().equals(super.getRazza())){
            Pokemon p=new Base(nomeF,genitore.getTipo1(),genitore.getTipo2(),super.getRazza(),super.getNumero(),(genitore.getPsMax()+super.getPsMax())/2,(genitore.getVelocita()+super.getVelocita())/2);
            return p;
        }
        return null;
    }
}
